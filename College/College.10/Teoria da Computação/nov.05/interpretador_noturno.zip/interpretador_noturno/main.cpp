int main()
{
	int a, b, c, d, e;
	a = 2;
	b = 0;
	c = 2;
	d = 0;
	e = 3;
	while(e >= 0)
	{
		while(a > 0)
		{
			while(c > 0)
			{
				b = b + 1;
				if(b != 1)
				{
					d = d - 1;
				}
				c = c - 1;
			}	
			a = a - 2;
		}
		e = e - 1;
	}
	return 0;
}