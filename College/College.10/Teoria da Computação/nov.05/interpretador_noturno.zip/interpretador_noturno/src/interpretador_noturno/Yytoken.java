package interpretador_noturno;

public interface Yytoken {

}
