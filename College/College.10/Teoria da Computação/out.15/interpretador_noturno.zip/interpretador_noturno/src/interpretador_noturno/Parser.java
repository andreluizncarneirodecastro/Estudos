package interpretador_noturno;

import java.io.FileReader;
import java.io.IOException;

public class Parser {

	private Token lookAhead;
	private Lexer lexer;
	private AnalisadorSemantico as;
	private MaquinaVirtual mv;
	
	public Parser(String arquivoFonte) throws IOException
	{
		
		// Instanciar um Lexer
		lexer = new Lexer(new FileReader(arquivoFonte));
		// Inicializar o lookAhead. lookAhead obtém o próximo Token!
		lookAhead = (Token) lexer.yylex();
		
		// Criar uma instância do analisador semântico.
		as = new AnalisadorSemantico();
		
		// Criar uma instância da máquina virtual.
		mv = new MaquinaVirtual(as);
	}
	
	public void match(TipoToken esperado) 
	{
		// Se o tipo do TOKEN esperado pela gramática foi o mesmo que foi lido
		if(esperado == lookAhead.getTipo())
		{	// Continua.
			try {
				lookAhead = (Token) lexer.yylex();
			}catch(IOException ex)
			{
				System.out.println("Erro ao ler o arquivo!");
			}
		}
		else
		{
			erro("esperado: "+String.valueOf(esperado)+" lido: "+String.valueOf(lookAhead.getTipo()));
		}
	}
	
	private void erro(String msg)
	{
		System.out.println("Erro sintático na linha "+lexer.linha+ ": "+msg);
		System.exit(0);
	}
	
	// Não terminal "programa"
	public void programa()
	{
		// Se caso o primeiro token não tiver LEXEMA igual a int, erro.
		if(!lookAhead.getLexema().equals("int"))
			erro("main deve ser do tipo int.");
		match(TipoToken.TIPO_DADO);
		
		// Se caso o token não tiver LEXEMA igual a main, erro.
		if(!lookAhead.getLexema().equals("main"))
			erro("não foi encontrada a função \"main\"");
		match(TipoToken.IDENTIFICADOR);
		
		match(TipoToken.ABRE_PARENTESES);
		match(TipoToken.FECHA_PARENTESES);
		
		match(TipoToken.INICIO_ESCOPO);
		corpo();
		System.out.println(as);
		match(TipoToken.FIM_ESCOPO);
		
		
	}
	
	private void corpo()
	{
		declaracao();
		corpoCMD();
		// Avaliar o return "0". O seu tem que ter!!!.
		if(!lookAhead.getLexema().equals("return"))
			erro("Está faltando a palavra reservada \"return\".");
		match(TipoToken.PALAVRA_RESERVADA);
		match(TipoToken.CONSTANTE_INTEIRA); 
		match(TipoToken.FIM_COMANDO);
	}
	
	private void declaracao()
	{
		if(lookAhead.getTipo() == TipoToken.TIPO_DADO)
		{
			
			String tipo = lookAhead.getLexema();			
			match(TipoToken.TIPO_DADO);
			
			// Avaliar se a variável NÃO foi previamente declarada.
			if(!as.verificaVariavelDuplicada(lookAhead))
				// Se não existir na tabela se símbolos, adicioná-la.
				as.insereVariavel(lookAhead, tipo);
			else
				erro("VARIAVEL "+lookAhead.getLexema()+ ", previamente declarada");
			match(TipoToken.IDENTIFICADOR);
			listaVar(tipo);
		}
	}
	
	private void listaVar(String tipo)
	{
		if(lookAhead.getTipo() == TipoToken.FIM_COMANDO)
		{
			match(TipoToken.FIM_COMANDO);
			declaracao();
		}
		else if(lookAhead.getTipo() == TipoToken.SEPARADOR_ARGUMENTO)
		{
			match(TipoToken.SEPARADOR_ARGUMENTO);
			// Avaliar se a variável NÃO foi previamente declarada.
			if(!as.verificaVariavelDuplicada(lookAhead))
				as.insereVariavel(lookAhead, tipo);
			else
				erro("VARIAVEL "+lookAhead.getLexema()+ ", previamente declarada");
			match(TipoToken.IDENTIFICADOR);
			listaVar(tipo);
		}
	}
	
	private void corpoCMD()
	{
		if(lookAhead.getTipo() == TipoToken.IDENTIFICADOR)
		{
			Token ladoEsquerdo = lookAhead;
			match(TipoToken.IDENTIFICADOR);
			match(TipoToken.OPERADOR_ATRIBUICAO);
			
			// Inicializar o tipo_expressão
			as.inicializaAvaliacaoTipo();
			expressao();
			
			// Aqui retorna o valor final da expressão aritmética. Atualizar a variável do lado esquerdo.
			String valorFinal = mv.getResultadoFinal();
			as.atualizaValor(ladoEsquerdo.getLexema(), valorFinal);
			
			if(as.checarPerdaPrecisao(ladoEsquerdo))
				System.out.println("ALERTA: Perda de precisão na linha "+lexer.linha);
			match(TipoToken.FIM_COMANDO);
			corpoCMD();
		}
	/*	else if(lookAhead.getTipo() == TipoToken.PALAVRA_RESERVADA)
		{
			comandoBloco();
			corpoCMD();
		} */
	}
	
	private void expressao()
	{
		termo();
		if(lookAhead.getLexema().equals("+") || lookAhead.getLexema().equals("-"))
		{
			// Empilha o operador + ou -.
			mv.empilha(lookAhead);
			match(TipoToken.OPERADOR_ARITMETICO);
			expressao();
		    // Ação semântica de calcular a expressão.
			mv.calcularExpressao();
		}
	}
	
	private void termo()
	{
		fator();
		if(lookAhead.getLexema().equals("*") || lookAhead.getLexema().equals("/"))
		{
			// Empilha o * ou /.
			mv.empilha(lookAhead);
			match(TipoToken.OPERADOR_ARITMETICO);
			termo();
			// Ação semântica de calcular a expressão.
			mv.calcularExpressao();
		}
	}
	
	private void fator()
	{
		if(lookAhead.getTipo() == TipoToken.IDENTIFICADOR)
		{
			// Aqui é avaliado o tipo do token encontrado!
			as.atualizaTipo(lookAhead);
			// Ação semântica de empilha o valor de um identificador.
			mv.empilha(lookAhead);
			
			match(TipoToken.IDENTIFICADOR);
		}
		else if(lookAhead.getTipo() == TipoToken.CONSTANTE_INTEIRA)
		{
			// Aqui é avaliado o tipo do token encontrado!
			as.atualizaTipo(lookAhead);
			// Ação semântica de empilha o valor de uma constante inteira.
			mv.empilha(lookAhead);
			
			match(TipoToken.CONSTANTE_INTEIRA);
		}	
		else
		{
			match(TipoToken.ABRE_PARENTESES);
			expressao();
			match(TipoToken.FECHA_PARENTESES);
		}
	}
	
	private void comandoBloco()
	{
		
	}
}
