package interpretador_noturno;

import java.util.Stack;

public class MaquinaVirtual {

	private Stack <Token> aritmetica;
	private AnalisadorSemantico as;
	
	public MaquinaVirtual(AnalisadorSemantico as)
	{
		aritmetica = new Stack<>();
		this.as = as;
	}
	
	public void empilha(Token t)
	{
		// Empilhar o novo Lexema de um token.
		aritmetica.push(t);
	}
	
	private String getValor(Token t)
	{
		String valor = "";
		if(t.getTipo() == TipoToken.IDENTIFICADOR)
			// Obter o valor da tabela de símbolos.
			valor = as.getValor(t.getLexema());
		else if(t.getTipo() == TipoToken.CONSTANTE_INTEIRA)
			// Obter o valor da constante.
			valor = t.getLexema();
		return valor;
	}
	
	public void calcularExpressao()
	{
		Token tokenOperando2 = aritmetica.pop();
		Token tokenOperandor = aritmetica.pop();
		Token tokenOperando1 = aritmetica.pop();
		
		String operando1 = getValor(tokenOperando1);
		String operando2 = getValor(tokenOperando2);
		String operador  = tokenOperandor.getLexema();
		
		// assumindo que tudo é inteiro! Converter os lexemas em números inteiros!
		int numOperando1 = Integer.parseInt(operando1);
		int numOperando2 = Integer.parseInt(operando2);
		int numResultado = 0;
		
		if(operador.equals("+"))
			numResultado = numOperando1 + numOperando2;
		else if(operador.equals("-"))
			numResultado = numOperando1 - numOperando2;
		else if(operador.equals("*"))
			numResultado = numOperando1 * numOperando2;
		else if(operador.equals("/"))
			numResultado = numOperando1 / numOperando2;
		
		// Converter novamente em string e reempilhar!
		String resultado = String.valueOf(numResultado);
		Token tokenResultado = new Token(resultado, TipoToken.CONSTANTE_INTEIRA);
		
		// Empilhar o resultado
		aritmetica.push(tokenResultado);
	}
	
	public String getResultadoFinal()
	{
		return aritmetica.pop().getLexema();
	}
}
