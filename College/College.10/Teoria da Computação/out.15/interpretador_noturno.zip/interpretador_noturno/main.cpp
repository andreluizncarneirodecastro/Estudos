int main()
{
	int a, b, casa, ra;
	int base, altura, teste;
	int letra, uxfgg, ch1;
	
	a    = 4;
	b    = 2;
	casa = 1;
	
	ra = (3 * a) / (b + 1) * casa;
	
	base = 10;
	
	altura = base + 4;
	
	return 0;
}