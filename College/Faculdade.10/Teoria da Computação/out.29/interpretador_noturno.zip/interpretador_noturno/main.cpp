int main()
{
	int a, b, casa, ra;
	int base, altura, teste;
	int letra, uxfgg, ch1;
	
	a    = 2;
	b    = 3;
	casa = 2;
	
	ra = 2 * casa / b;
	
	base = 10;
	
	altura = base + 4;
	
	if(a == 2 && b == 3 && ra != 1){
	}
	
	if(base > 10 / 4 * uxfgg)
	{
		teste = 3;	
		
		if(ch1 == 10)
		{
			a = 9;
		}
		letra = 1000;
	}
	
	
	return 0;
}