int main()
{
	int a, b, casa, ra;
	float base, altura, teste;
	char letra, uxfgg, ch1;
	return 0;
}