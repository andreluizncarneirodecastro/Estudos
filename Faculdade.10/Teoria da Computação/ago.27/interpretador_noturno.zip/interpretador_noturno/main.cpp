int main()
{
    a = int;
	int a, b, c;
	float preco;
	char letra;
	double temperatura;
	
	a = b + c;
	preco = 10.4;
	if(preco > 10)
	{
		a++;
	}
	else
	{
		while(casa > 90)
		{	
			casa = a - b;
			preco = a + b / 5 * casa;
		}
		if(c <= 9 && d > 10)
		{
			a = 5 * preco;
		}
	}
	return 0;
}